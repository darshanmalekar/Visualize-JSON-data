import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-time-table></app-time-table>'
})
export class AppComponent {}
