import { Component, OnInit } from '@angular/core';
import { TimeService } from '../time.service';
import { ChartData, ChartOptions } from 'chart.js';

@Component({
  selector: 'app-time-table',
  templateUrl: './time-table.component.html',
  styleUrls: ['./time-table.component.css']
})
export class TimeTableComponent implements OnInit {
  aggregated: { name: string; hours: number }[] = [];
  totalHours = 0;

  pieData: ChartData<'pie', number[], string | string[]> = {
    labels: [],
    datasets: [{ data: [] }]
  };
  pieOptions: ChartOptions<'pie'> = {
    responsive: true,
    plugins: { legend: { position: 'right' } }
  };

  loading = true;
  error: string | null = null;

  constructor(private svc: TimeService) {}

  ngOnInit(): void {
    this.svc.getEntries().subscribe({
      next: data => {
        const arr = Array.isArray(data) ? data : (data?.items ?? []);
        const map = new Map<string, number>();

        for (const e of arr) {
          const name = this.getName(e) || 'Unknown';
          const hours = this.getHoursFromEntry(e);
          const prev = map.get(name) ?? 0;
          map.set(name, prev + hours);
        }

        this.aggregated = Array.from(map.entries()).map(([name, hours]) => ({ name, hours }));
        this.aggregated.sort((a, b) => b.hours - a.hours);
        this.totalHours = this.aggregated.reduce((s, it) => s + it.hours, 0);

        this.pieData.labels = this.aggregated.map(a => a.name);
        this.pieData.datasets[0].data = this.aggregated.map(a => Math.max(0, +a.hours.toFixed(2)));

        this.loading = false;
      },
      error: err => {
        this.error = 'Failed to load time entries. Check console for details.';
        console.error(err);
        this.loading = false;
      }
    });
  }

  private getName(e: any): string | null {
    return e?.employeeName ?? e?.name ?? e?.employee ?? e?.user ?? null;
  }

  private getHoursFromEntry(e: any): number {
    if (!e) return 0;
    const numericCandidates = ['hours','Hours','durationHours','timeHours','time'];
    for (const k of numericCandidates) {
      const v = e[k];
      if (typeof v === 'number' && !isNaN(v)) return v;
      if (typeof v === 'string' && !isNaN(Number(v))) return Number(v);
    }
    const minutesCandidates = ['minutes','Minutes','timeMinutes','durationMinutes'];
    for (const k of minutesCandidates) {
      const v = e[k];
      if (typeof v === 'number' && !isNaN(v)) return v / 60;
      if (typeof v === 'string' && !isNaN(Number(v))) return Number(v) / 60;
    }
    if (e.start || e.end || e.Start || e.End) {
      const start = new Date(e.start ?? e.Start);
      const end = new Date(e.end ?? e.End);
      if (!isNaN(start.valueOf()) && !isNaN(end.valueOf())) {
        const diffHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
        if (!isNaN(diffHours) && diffHours > 0) return diffHours;
      }
    }
    const dur = e.duration ?? e.Duration ?? e.isoDuration;
    if (typeof dur === 'string' && (dur.startsWith('P') || dur.startsWith('PT'))) {
      const matchH = dur.match(/(\d+)H/);
      const matchM = dur.match(/(\d+)M/);
      const h = matchH ? Number(matchH[1]) : 0;
      const m = matchM ? Number(matchM[1]) : 0;
      const total = h + m/60;
      if (total > 0) return total;
    }
    return 0;
  }

  rowClass(hours: number) {
    return {
      'low-hours': hours < 100
    };
  }
}
