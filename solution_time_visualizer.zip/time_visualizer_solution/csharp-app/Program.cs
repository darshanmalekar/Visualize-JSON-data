using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using ScottPlot;

class Program
{
    static async Task Main()
    {
        var url = "https://rc-vault-fap-live-1.azurewebsites.net/api/gettimeentries?code=vO17RnE8vuzXzPJo5eaLLjXjmRW07law99QTD90zat9FfOQJKKUcgQ==";
        Console.WriteLine("Fetching data...");
        using var http = new HttpClient();
        var resp = await http.GetStringAsync(url);

        JsonDocument doc = JsonDocument.Parse(resp);
        JsonElement root = doc.RootElement;

        var array = root.ValueKind == JsonValueKind.Array ? root.EnumerateArray() : (root.TryGetProperty("items", out var items) && items.ValueKind == JsonValueKind.Array ? items.EnumerateArray() : default);

        if (array == default)
        {
            Console.WriteLine("Unexpected JSON shape. Root is not an array and does not contain 'items'. Aborting.");
            return;
        }

        var map = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        foreach (var el in array)
        {
            string name = GetName(el);
            double hours = GetHoursFromElement(el);
            if (string.IsNullOrWhiteSpace(name)) name = "Unknown";
            if (!map.ContainsKey(name)) map[name] = 0;
            map[name] += hours;
        }

        var list = new List<(string name, double hours)>();
        foreach (var kv in map) list.Add((kv.Key, kv.Value));
        list.Sort((a,b) => b.hours.CompareTo(a.hours));
        double total = 0;
        foreach(var it in list) total += it.hours;

        var html = GenerateHtml(list, total);
        var htmlPath = Path.Combine(Directory.GetCurrentDirectory(), "employees.html");
        File.WriteAllText(htmlPath, html);
        Console.WriteLine($"Wrote {htmlPath}");

        var labels = new List<string>();
        var values = new List<double>();
        foreach(var it in list) { labels.Add(it.name); values.Add(it.hours); }

        if (values.Count == 0)
        {
            Console.WriteLine("No data to chart.");
            return;
        }

        var plt = new ScottPlot.Plot(600, 400);
        plt.Style(figureBackground: System.Drawing.Color.White);
        plt.AddPie(values.ToArray(), labels.ToArray());
        plt.Legend(location: ScottPlot.Alignment.UpperRight);
        var pngPath = Path.Combine(Directory.GetCurrentDirectory(), "pie.png");
        plt.Save(pngPath);
        Console.WriteLine($"Wrote {pngPath}");
    }

    static string GetName(JsonElement el)
    {
        if (el.TryGetProperty("employeeName", out var v) || el.TryGetProperty("name", out v) || el.TryGetProperty("employee", out v) || el.TryGetProperty("user", out v))
            return v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : v.ToString();
        return "";
    }

    static double GetHoursFromElement(JsonElement el)
    {
        string[] numeric = { "hours","Hours","durationHours","timeHours","time" };
        foreach (var k in numeric)
        {
            if (el.TryGetProperty(k, out var v))
            {
                if (v.ValueKind == JsonValueKind.Number && v.TryGetDouble(out var d)) return d;
                if (v.ValueKind == JsonValueKind.String && double.TryParse(v.GetString(), out var d2)) return d2;
            }
        }

        string[] minutes = { "minutes","Minutes","timeMinutes","durationMinutes" };
        foreach (var k in minutes)
        {
            if (el.TryGetProperty(k, out var v))
            {
                if (v.ValueKind == JsonValueKind.Number && v.TryGetDouble(out var d)) return d / 60.0;
                if (v.ValueKind == JsonValueKind.String && double.TryParse(v.GetString(), out var d2)) return d2 / 60.0;
            }
        }

        if ( (el.TryGetProperty("start", out var s) || el.TryGetProperty("Start", out s)) &&
             (el.TryGetProperty("end", out var e) || el.TryGetProperty("End", out e)) )
        {
            if (s.ValueKind == JsonValueKind.String && e.ValueKind == JsonValueKind.String)
            {
                if (DateTime.TryParse(s.GetString(), out var ds) && DateTime.TryParse(e.GetString(), out var de))
                {
                    var diff = de - ds;
                    return Math.Max(0, diff.TotalHours);
                }
            }
        }

        if (el.TryGetProperty("duration", out var dur) && dur.ValueKind == JsonValueKind.String)
        {
            var dstr = dur.GetString();
            if (!string.IsNullOrEmpty(dstr))
            {
                var h = 0; var m = 0;
                var mh = System.Text.RegularExpressions.Regex.Match(dstr, @"(\d+)H");
                var mm = System.Text.RegularExpressions.Regex.Match(dstr, @"(\d+)M");
                if (mh.Success) int.TryParse(mh.Groups[1].Value, out h);
                if (mm.Success) int.TryParse(mm.Groups[1].Value, out m);
                return h + m/60.0;
            }
        }

        return 0;
    }

    static string GenerateHtml(List<(string name,double hours)> list, double total)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("<!doctype html>");
        sb.AppendLine("<html><head><meta charset='utf-8'><title>Employees hours</title>");
        sb.AppendLine("<style>");
        sb.AppendLine("table { border-collapse: collapse; width: 100%; }");
        sb.AppendLine("th, td { padding: 8px 10px; border: 1px solid #ddd; }");
        sb.AppendLine(".low { background-color: #ffecec; }");
        sb.AppendLine("</style>");
        sb.AppendLine("</head><body>");
        sb.AppendLine($"<h2>Employees — total hours (Total: {total:F2} h)</h2>");
        sb.AppendLine("<table><thead><tr><th>#</th><th>Name</th><th>Total hours</th><th>%</th></tr></thead><tbody>");
        int i = 1;
        foreach(var it in list)
        {
            var cls = it.hours < 100.0 ? " class='low' " : "";
            var pct = total > 0 ? it.hours / total * 100.0 : 0.0;
            sb.AppendLine($"<tr{cls}><td>{i}</td><td>{System.Net.WebUtility.HtmlEncode(it.name)}</td><td>{it.hours:F2}</td><td>{pct:F1}%</td></tr>");
            i++;
        }
        sb.AppendLine("</tbody></table>");
        sb.AppendLine("</body></html>");
        return sb.ToString();
    }
}
