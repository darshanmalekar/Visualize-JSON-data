# Time Visualizer — Angular + C# solutions

This repository contains two solutions for the Time Visualizer tasks:

- **Angular**: an Angular component that fetches time entries from the provided REST endpoint, aggregates total hours per employee, displays a sorted HTML table (rows highlighted if <100 hours), and shows a pie chart using Chart.js (ng2-charts).
- **C#**: a .NET console app that fetches the same endpoint, generates an `employees.html` (table) and a `pie.png` (pie chart) using ScottPlot.

## How to use

### Option A — Run Angular app locally
1. Install Node.js (16+) and npm.
2. In the `angular-app` folder:
   ```bash
   npm install
   npx ng serve --open
   ```
   The app will open at `http://localhost:4200`.

### Option B — Build & run C# app
1. Install .NET 6+ SDK.
2. In the `csharp-app` folder:
   ```bash
   dotnet restore
   dotnet run
   ```
   Outputs:
   - `employees.html`
   - `pie.png`

## How to publish to GitHub
1. Create a new repository on GitHub (do not initialize with README).
2. From your local folder containing the files:
   ```bash
   git init
   git add .
   git commit -m "Add Time Visualizer solutions (Angular + C#)"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
Replace `<your-username>` and `<repo-name>` accordingly.

## Notes
- The Angular component expects the API endpoint URL included in the task. If the API response uses different field names, adjust the mapping functions in the code (`getHoursFromEntry` in Angular and `GetHoursFromElement` in C#).
- If you'd like, I can prepare a direct GitHub repository for you — I cannot push to your GitHub automatically, but I can provide the exact commands or a GitHub Actions workflow if you want automated publishing.
